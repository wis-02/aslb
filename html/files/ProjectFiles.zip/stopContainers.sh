#!/bin/bash

#This script will stop all running containers such that you don't have any "zombie" containers

docker stop $(docker ps -a -q)
docker rm $(docker ps -a -q)
