#!/bin/bash

#Start timer
start=$(date +%s)

load='-\|/'

echo "Enter the number of clients you wish to run: "

#Receive input for number of clients you wish to run (Must be equal to num of clients available)
read numOfClients

echo "Enter the client number you wish to start at: "
read firstClient

echo "Running..."

i=0
#Run each client and move it to the background to be controlled by host OS
for ((num = 1; num <= numOfClients; num++))
do
	#docker call to instanciate a client container
	docker run -v $(pwd)/client$firstClient:/usr/src/app client ./runClient.sh &
	firstClient=$((firstClient + 1))
	
	#loading image :)
	i=$(( (i+1) %4 ))
	sleep .1
	printf "\r${load:$i:1}"
done

#wait for loop to finish before calculating execution time
wait

end=$(date +%s)
total=$((end-start))

echo
echo "Time to execute: $total seconds"

echo All done
