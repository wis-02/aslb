#!/bin/bash

#run a loop over all directories
for dir in */
do
#change into directory
	cd $dir
#remove any files inside of clientStats if it exists
	rm clientStats/*
#move back to the parent directory
	cd ..
done


