#!/bin/bash

echo "Enter number of Clients you wish to create: "
read numOfClients

echo "Enter number of first Client you wish to create: "
read firstClient

#loop for the number of clients the user wishes to create
for ((num = 1; num <= numOfClients; num++))
do
	#Copy files from master version of client and make duplicates
	cp -r client-alpine client$firstClient
	firstClient=$((firstClient + 1))
done

echo "$numOfClients clients created."
