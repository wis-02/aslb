#!/bin/bash
echo
echo "Creating client image..."

docker build -t client .
echo
echo "Client image created."
echo
