#!/bin/bash

#get input for file that needs to be downloaded
read url

DATE=$(date)

#setup log file with information about start time and create file with start time as title
echo "Client started: $DATE" > clientStats/"$DATE.txt"

echo >> clientStats/"$DATE.txt"

#run loop to download file that many times, this can be changed by changing the loop range
for i in {1..100}
do
#download the file and add output to tmp file
	wget -v -o clientStats/"tmp.txt" $url
#rm file downloaded
	rm -f *.jpg *.txt
#grab the last line from the tmp file and append it to log file previously created
	tail -2 clientStats/"tmp.txt" >> clientStats/"$DATE.txt"
#echo a blank line to the log for formatting
	echo >> clientStats/"$DATE.txt"
done

echo "Client ended: $(date)" >> clientStats/"$DATE.txt"
