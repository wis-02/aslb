#!/bin/bash

#pass the url to download from to download script
./downloadFiles.sh < url
