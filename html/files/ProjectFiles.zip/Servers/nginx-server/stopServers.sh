#!/bin/bash

echo "Enter number of Servers you wish to stop: "
read numOfServers

echo "Enter the server number you wish to start at: "
read serverNum

#run loop to stop servers starting at the server specified by the user and stop as many as the user specifies
for ((num = 1; num <= numOfServers; num++))
do
#stop the docker container
	docker stop server$serverNum
#delete instanciation of server to free space
	docker rm server$serverNum
#increase serverNum so that the next server can be stopped
	serverNum=$((serverNum + 1))

done

echo "Server(s) stopped."
