#!/bin/bash
echo
echo "Creating server image..."

docker build -t servers .
echo
echo "Server image created."
echo
