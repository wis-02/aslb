#!/bin/bash

#Start timer
start=$(date +%s)

echo "Enter the number of servers you wish to get statistics of: "

#Receive input for number of clients you wish to run (Must be equal to num of clients available)
read numOfServers

echo "Enter IP address of servers: "

read serverIP

echo "Enter port number in which server group starts: "

read serverPort

echo "Grabbing files..."

#Run each client and move it to the background to be controlled by host OS
for ((num = 1; num <= numOfServers; num++))
do
#docker call to instanciate a client container
	wget -O serverStats/server$num.html http://$serverIP:$serverPort/nginx_status
    serverPort=$((serverPort + 1))
done

echo All done
