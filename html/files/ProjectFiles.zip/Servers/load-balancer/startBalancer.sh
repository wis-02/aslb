#!/bin/bash

#--name allows you to name the instance of the original image being run
#-d runs container detached from original image
#-p associates local port 8080 to port 80 of the container
#-v mounts local directory to container directory

docker run --name load-balancer -d -p 8080:80 -v ~/Documents/Docker/senior-design/Servers/load-balancer/:/etc/nginx/conf.d/ load-balancer
