#!/bin/bash

echo
echo "Creating load-balancer image..."

docker build -t load-balancer .
echo
echo "Load-balancer image created."
echo
